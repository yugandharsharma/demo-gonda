<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Model\Coupon;
use App\Model\HomeSection6;
use App\Model\Notification;
use App\Model\UserTransaction;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Stripe\Charge;
use Stripe\Customer;
use Stripe\EphemeralKey;
use Stripe\PaymentIntent;
use Stripe\Stripe;
use Stripe\StripeClient;

class StripePaymentController extends Controller
{
    private $stripe;
    public function __construct()
    {
        $this->stripe = new StripeClient(env('STRIPE_SECRET'));
    }

    public static function createStripeCustomer($name, $mobile_number){

        $stripe = new StripeClient(
                env('STRIPE_SECRET')
            );

        $customer = $stripe->customers->create([
                'name' => $name,
                'phone' => $mobile_number
            ]);

        return $customer;
    }

    public function createCard(Request $request){
        $validator = Validator::make($request->all(), [
            'token' => 'required',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
//        $stripe = new StripeClient(
//            env('STRIPE_SECRET')
//        );
        $user = User::where('id', auth('api')->id())->first();
        if (!empty($user)){

            $cart_list = $this->stripe->customers->allSources(
                $user->stripe_customer_id
            );

            if (count($cart_list) == 0){

                $data = $this->stripe->customers->update(
                    $user->stripe_customer_id,
                    ['source' => $request['token']]
                );
            }
            else{
                $data = $this->stripe->customers->createSource(
                    $user->stripe_customer_id,
                    ['source' => $request['token']]
                );
            }

            $latest_card_list = $this->stripe->customers->allSources(
                $user->stripe_customer_id
            );
            return response()->json([
                'status' => 1,
                'message' => 'Your card has been added.',
                'data' => $data,
                'cart_listing' => $latest_card_list
            ]);
        }
        return response()->json([
            'status' => 0,
            'message' => 'Something went wrong.',
        ]);
    }

    public static function cardList(){
        $stripe = new StripeClient(
            env('STRIPE_SECRET')
        );
        $user = User::where('id', auth('api')->id())->first();

        if (!empty($user)){

            $data = $stripe->customers->allSources(
                $user->stripe_customer_id,
                ['object' => 'card']
            );
            return $data;
        }
    }

    public function deleteCard(Request $request){
        $validator = Validator::make($request->all(), [
            'token' => 'required',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        $stripe = new StripeClient(
            env('STRIPE_SECRET')
        );
        $user = User::where('id', auth('api')->id())->first();
        if (!empty($user)){
            $data = $stripe->customers->deleteSource(
                $user->stripe_customer_id,
                $request['token'],
                []
            );
            return response()->json([
                'status' => 1,
                'message' => 'Your card has been deleted.',
                'data' => $data
            ]);
        }
        return response()->json([
            'status' => 0,
            'message' => 'Something went wrong.'
        ]);
    }

    public function stripe(Request $request)
    {
//        $validator = Validator::make($request->all(), [
//            'plan_id' => 'required|exists:home_section6s,id',
//            'promo_code' => 'required|exists:coupons',
//        ]);
//        if ($validator->fails()){
//            $error = $validator->errors()->first();
//            return response()->json([
//                "status" => 0,
//                "message" => $error,
//            ]);
//        }
//        $plan = HomeSection6::where(['id' => $request['plan_id'], 'status' => 1])->first();
//
//        $stripe = Stripe::setApiKey(env('STRIPE_SECRET'));
//
//        $stripe = new StripeClient(
//            env('STRIPE_SECRET')
//        );
////        $token  =  $stripe->tokens->create([
////            'card' => [
////                'number' => $request['number'],
////                'exp_month' => $request['exp_month'],
////                'exp_year' => $request['exp_year'],
////                'cvc' => $request['cvc'],
////            ],
////        ]);
//        $Tncdetail= Charge::create ([
//            "amount" => ($plan->price) * 100,
//            "currency" => "usd",
//            "source" => $request['token'],
//            //"source" => $token->id,
//            "description" => "Test payment from gonda.com."
//        ]);
//        if ($Tncdetail->status == 'succeeded'){
//            $user_transaction = UserTransaction::where(['user_id' => auth('api')->id(),
//                                    'plan_id'=>$plan->id])->first();
//            if (empty($user_transaction)) {
//                $user_transaction = new UserTransaction();
//                $user_transaction->user_id = auth('api')->id();
//                $user_transaction->transaction_id = $Tncdetail->balance_transaction;
//                $user_transaction->plan_id = $request['plan_id'];
//                $user_transaction->plan_name = $plan->title;
//                $user_transaction->credit_points = $plan->credit_points ?? 0;
//                $user_transaction->status = 0;
//                $user_transaction->save();
//            }
//                $user_transaction->user_id = auth('api')->id();
//                $user_transaction->transaction_id = $Tncdetail->balance_transaction;
//                $user_transaction->plan_id = $request['plan_id'];
//                $user_transaction->plan_name = $plan->title;
//                $user_transaction->credit_points += $plan->credit_points;
//                $user_transaction->status = 1;
//                $user_transaction->save();
//        }
//        return response()->json([
//            'status' => 1,
//            'message' => 'Payment successful!',
//            'data' => $Tncdetail,
//            'user_transaction' => $user_transaction
//        ]);

        $validator = Validator::make($request->all(), [
            'plan_id' => 'required|exists:home_section6s,id',
            //'promo_code' => 'sometimes|nullable|exists:coupons',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }

        $stripe = Stripe::setApiKey(env('STRIPE_SECRET'));

        $stripe = new StripeClient(
            env('STRIPE_SECRET')
        );
        $plan_id = $request['plan_id'];
        $promo_code = $request['promo_code'];
        $user = User::where('id', auth('api')->id())->first();

        $coupon = Coupon::where('promo_code', $promo_code)->first();

        $plan = HomeSection6::where('id', $plan_id)->first();

        $strip_id = [];

        $is_valid_promo_code = Coupon::isValidPromoCode($promo_code);

        if (!empty($plan) && !empty($coupon)) {
            $discount = ($coupon->discount / 100) * $plan->price;
            $actual_pay = $plan->price - $discount;
        }
        else{
            $actual_pay = $plan->price;
        }
        if (!empty($user)){
            $strip_id = $user->stripe_id;
        }
        $ephemeralKey = EphemeralKey::create(
            ['customer' => $strip_id],
            ['stripe_version' => '2020-08-27']
        );
        $paymentIntent = PaymentIntent::create([
            'amount' => $actual_pay * 100,
            'currency' => 'usd',
            'customer' => $strip_id
        ]);
        return response()->json([
            'status' => 1,
            'paymentIntent' => $paymentIntent->client_secret,
            'ephemeralKey' => $ephemeralKey->secret,
            'customer' => $strip_id,
            'discount' => $discount ?? 0,
            'actual_pay' => $actual_pay,
            'is_valid_promo_code' => $is_valid_promo_code
        ]);
    }

    public function createStripSubscription(Request $request){
        $validator = Validator::make($request->all(), [
            'plan_id' => 'required|exists:home_section6s,id',
            'token' => 'required',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        $stripe = new StripeClient(
            env('STRIPE_SECRET')
        );

        $plan_id = $request['plan_id'];

        $user = User::where('id', auth('api')->id())->first();

        $plan = HomeSection6::where('id', $plan_id)->first();

        if (!empty($user) && !empty($plan)){

            $add_card = $stripe->customers->update(
                $user->stripe_customer_id,

                ['invoice_settings' => ['default_payment_method' => $request['token']]]
            );
            //dd($plan->stripe_plan_id);
            $subscription_data = $stripe->subscriptions->create([
                'customer' => $user->stripe_customer_id,
                'items' => [
                    ['price' => $plan->stripe_plan_id],
                ],
            ]);

            if ($subscription_data){
            $user_transaction = UserTransaction::where('user_id', auth('api')->id())->first();
            $user = User::where('id', auth('api')->id())->first();
            if (empty($user_transaction)) {
                $user_transaction = new UserTransaction();
                $user_transaction->user_id = auth('api')->id();
                $user_transaction->stripe_subscription_id = $subscription_data->id;
                $user_transaction->plan_id = $request['plan_id'];
                $user_transaction->plan_name = $plan->title;
                $user_transaction->plan_start_date = Carbon::now();
                $user_transaction->plan_end_date = Carbon::now()->addDays(30);
                $user_transaction->credit_points = $plan->credit_points ?? 0;
                $user_transaction->status = 1;
                $user_transaction->save();
                $user->total_credit_points = $user_transaction->credit_points ?? 0;
                if ($user_transaction->plan_id != 3){
                    $user->is_premium = 0;
                }
                else{
                    $user->is_premium = 1;
                }
                $user->save();

            }
                $user_transaction->user_id = auth('api')->id();
                $user_transaction->stripe_subscription_id = $subscription_data->id;
                $user_transaction->plan_id = $request['plan_id'];
                $user_transaction->plan_name = $plan->title;
                $user_transaction->credit_points += $plan->credit_points;
                $user_transaction->plan_start_date = Carbon::now();
                $user_transaction->plan_end_date = Carbon::now()->addDays(30);
                $user_transaction->status = 1;
                $user_transaction->save();
                $user->total_credit_points = $user_transaction->credit_points ?? 0;
                if ($user_transaction->plan_id != 3){
                    $user->is_premium = 0;
                }
                else{
                    $user->is_premium = 1;
                }
                $user->save();
            }
            $user_transaction['is_premium'] = $user->is_premium;
            $notification = new Notification();
            $notification->comment = 'You have subscribed to our "'.strtoupper($user_transaction->plan_name).'" plan';
            $notification->type = 'subscription';
            $notification->user_id = auth('api')->id();
            $notification->save();

            return response()->json([
                'status' => 1,
                'message' => 'You have subscribed to our "'.strtoupper($user_transaction->plan_name).'" plan',
                'data' => $subscription_data,
                'current_plan' => $user_transaction
            ]);
        }

        return response()->json([
            'status' => 0,
            'message' => 'Something went wrong.'
        ]);
    }

    public function applyPromoCode(Request $request){
        $validator = Validator::make($request->all(), [
            'plan_id' => 'required|exists:home_section6s,id',
            'promo_code' => 'required|exists:coupons',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        $plan_id = $request['plan_id'];

        $promo_code = $request['promo_code'];

        $coupon = Coupon::where('promo_code', $promo_code)->first();

        $plan = HomeSection6::where('id', $plan_id)->first();

        $is_valid_promo_code = Coupon::isValidPromoCode($promo_code);

        if (!empty($plan) && !empty($coupon)) {
            $discount = ($coupon->discount / 100) * $plan->price;
            $actual_pay = $plan->price - $discount;
        }
        else{
            $actual_pay = $plan->price;
        }
        return response()->json([
            'status' => 1,
            'discount' => $discount ?? 0,
            'actual_pay' => $actual_pay,
            'is_valid_promo_code' => $is_valid_promo_code
        ]);
    }

    public function deleteSubscription(Request $request){
        try{
            $user_transaction = UserTransaction::where('user_id', auth('api')->id())->first();

            if ($user_transaction){

                $notification = new Notification();
                $notification->comment = 'You have unsubscribed from our "'.strtoupper($user_transaction->plan_name).'" plan';
                $notification->type = 'unsubscribe';
                $notification->user_id = auth('api')->id();
                $notification->save();

                $this->stripe->subscriptions->cancel(
                    $user_transaction->stripe_subscription_id
                );

                $user_transaction->delete();

                return response()->json([
                    'status' => 1,
                    'message' => 'You have unsubscribed.',
                    'data' => []
                ]);
            }
            return response()->json([
                'status' => 1,
                'message' => 'No Records',
                'data' => []
            ]);
        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }
}
