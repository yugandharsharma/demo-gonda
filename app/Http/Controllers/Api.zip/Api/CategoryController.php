<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Model\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function list(){
        $category = Category::orderBy('created_at', 'desc')->get();
        if ($category->isNotEmpty()){
            return response()->json([
               'status' => 200,
               'message' => 'All Records',
               'data' => $category
            ]);
        }
        return response()->json([
            'status' => 200,
            'message' => 'No Records',
            'data' => []
        ]);
    }
}
