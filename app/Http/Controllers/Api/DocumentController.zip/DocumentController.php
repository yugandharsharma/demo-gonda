<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Model\Contact;
use App\Model\Document;
use App\Model\EmailTemplateManagement;
use App\Model\GlobalSettingManagement;
use App\Model\HomeSection6;
use App\Model\Notification;
use App\Model\TemplateManagement;
use App\Model\Transaction;
use App\Model\UserTransaction;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Mpdf\Mpdf;
use Stripe\StripeClient;

class DocumentController extends Controller
{
    public function add(Request $request){
        $validator = Validator::make($request->all(),[
            'contacts' => 'required|array',
            'contacts.*.contact_id' => 'required|exists:contacts,id',
            'contacts.*.document_id' => 'sometimes|nullable|exists:documents,id',
            'content' => 'required|string',
            'state_id' => 'required',
            'template' => 'required',
            'auto_sign' => 'required|in:0,1',
            'type' => 'required|in:1,2',
        ],[
            'contact_id.*.exists' => 'The entered contact id does not exists.',
            'contact_id.*.unique' => 'The contact id has already been taken.',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        $document_data = [];
        $user_data = [];
        try {
            DB::beginTransaction();
            $user = auth('api')->user();
            $global_setting = GlobalSettingManagement::first();
            if (!empty($request['contacts'])){
                $last_draft = Document::where('type',2)->latest()->first('batch');
                $batch = !empty($last_draft) ? $last_draft->batch + 1 : 1;
                foreach ($request['contacts'] as $contact){
                    if(!empty($contact['document_id'])) {
                        $document = Document::find($contact['document_id']);
                        $document->status = 1;
                        $document->type = 1;
                        $document->batch = 0;
                        $document->save();
                        $document_data[] = $document;
                    }
                    else {
                        $document = new Document();
                        $document->user_id = auth('api')->id();
                        $document->contact_id = $contact['contact_id'];
                        $document->content = $request['content'];
                        $document->state_id = $request['state_id'];
                        $document->template = $request['template'];
                        $document->auto_sign = $request['auto_sign'];
                        $document->sender_sign = $request['auto_sign'] == 1 ? $user->sign_image : null;
                        $document->type = $request['type'];
                        $document->status = $request['type'] == 1 ? 1 : 0;
                        $document->batch = $request['type'] == 1 ? 0 : $batch;
                        $document->save();
//                        if ($document->contact) {
//                            $receiver_user_id = $document->contact->userByMobileNumber->id ?? null;
//                            $sender_contact_number = $user->mobile_number;
//                            if($receiver_user_id) {
//                                $receiver_contact_id = Contact::where([
//                                    'user_id' => $receiver_user_id,
//                                    'contact_mobile_number' => $sender_contact_number
//                                ])->first();
//                                $document->receiver_contact_id = $receiver_contact_id->id;
//                                $document->save();
//                            }
//                        }

                        // update sender and receiver details
                        $document->sender_details = json_encode($document->user);
                        $document->receiver_details = json_encode($document->contact->userByMobileNumber);
                        $document->save();

                        $notification_to_sender = new Notification();
                        $notification_to_sender->comment = "You have sent document(#".$document->id.") to ".ucfirst($document->contact->contact_first_name)." ".ucfirst($document->contact->contact_last_name);
                        $notification_to_sender->type = 'document';
                        $notification_to_sender->document_id = $document->id;
                        $notification_to_sender->user_id = $document->user_id;
                        $notification_to_sender->save();

                        $notification_to_receiver = new Notification();
                        $notification_to_receiver->comment = "You have received document(#".$document->id.") to sign from ".ucfirst($document->user->first_name)." ".ucfirst($document->user->last_name);
                        $notification_to_receiver->type = 'document';
                        $notification_to_receiver->document_id = $document->id;
                        $notification_to_receiver->user_id = $document->contact->userByMobileNumber->id ?? null;
                        $notification_to_receiver->save();

                        $document['global_content'] = $global_setting->content;
                        $document_data[] = $document;
                    }
                }
                if ($document_data){
                    foreach ($document_data as $contact_data){
                        $contact = Contact::where('id', $contact_data->contact_id)->first();
                        if ($contact){
                            $user = User::where('mobile_number', $contact->contact_mobile_number)->first();
                            if ($user){
                                $user_data = $user->sign_image;
                            }
                        }
                    }
                }
                DB::commit();
                return response()->json([
                    'status' => 1,
                    'message' => $document->type == 1 ? "Your document has been sent." : "Your document has been saved to My Drafts.",
                    'sign_image_path' => URL::to('/').'/public/storage/uploads/user-sign/',
                    'data' => $document_data,
                    'sign_image' => $user_data,
                ]);
            }

        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }

    public function docList(Request $request){
        try{
            $user = auth('api')->user();
            if ($user){
                $contact = Contact::where('contact_mobile_number', $user->mobile_number)->pluck('id');

                $documents = Document::with('contact.userByMobileNumber','stateUs:id,name','user:id,first_name,last_name,profile_image,sign_image')
                        ->where('type', 1)
                        ->where(function ($query) use ($contact){
                            $query->whereIn('contact_id', $contact)
                                ->orWhere('user_id', auth('api')->id());
                        })
                        ->orderBy('created_at', 'desc')
                        ->paginate(10);

                    if ($documents->isNotEmpty()){
                        foreach ($documents as $document){
                            //1 => receiver , 0 => sender
                            $document->is_received = $document->user_id == auth('api')->id() ? 0 : 1;
                            $document->can_send_reminder = $document->reminder_sent_at <= Carbon::now()->subHours(24) ? 1 : 0;
                            $document->sender_details = json_decode($document->sender_details);
                            $document->receiver_details = json_decode($document->receiver_details);
                        }
                    }
                return response()->json([
                    "status" => 1,
                    "message" => 'Contact List',
                    'contact_image_path' => URL::to('/') . '/public/storage/uploads/contact-image/',
                    'profile_image_path' => URL::to('/').'/public/storage/uploads/user-profile/',
                    'sign_image_path' => URL::to('/').'/public/storage/uploads/user-sign/',
                    'template_path' => URL::to('/').'/public/storage/uploads/pdf/',
                    "data" => $documents,
                    'current_plan' => HomeSection6::userTransactions(),
                ]);

            }
        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }

    public function receivedDocumentList(){
        try{

           $document = Document::with('contact','stateUs:id,name')
                                    ->where('contact_id', auth('api')->id())
                                    ->paginate(10);
           if ($document->isNotEmpty()){
               return response()->json([
                   "status" => 1,
                   "message" => 'Contact List',
                   'contact_image_path' => URL::to('/') . '/public/storage/uploads/contact-image/',
                   "data" => $document
               ]);
           }
            return response()->json([
                "status" => 1,
                "message" => 'No Records',
                "data" => []
            ]);
        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }

    public function statusChange(Request $request){
        $validator = Validator::make($request->all(),[
            'document_id' => 'required|exists:documents,id',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        try{
           $document = Document::with('stateUs:id,name','user:id,first_name,last_name,profile_image,sign_image','contact.userByMobileNumber')
                                ->where('id', $request['document_id'])->first();
           // when sender complete document with auto sign
           if ($document->auto_sign == 1 && $document->status == 2){
               //$document->sender_sign = $document->user->sign_image;
               $document->status = 3;
               $document->save();
           }
           // when sender not doing auto sign
           elseif ($document->auto_sign == 0 && $document->status == 2){
               if ($request->has('sender_sign')) {
                   $filename = base64_to_image_sign($request['sender_sign']);
                   $document->sender_sign = $filename;
               }
               else {
                   $document->sender_sign = $document->user->sign_image;
               }
               $notification_to_sender = new Notification();
               $notification_to_sender->comment = "You have signed the document(#".$document->id.")";
               $notification_to_sender->type = 'document';
               $notification_to_sender->document_id = $document->id;
               $notification_to_sender->user_id = $document->user_id;
               $notification_to_sender->save();

               $document->status = 3;
               $document->save();

               $notification_to_receiver = new Notification();
               $notification_to_receiver->comment = "Document(#" . $document->id . ") has been completed";
               $notification_to_receiver->type = 'document';
               $notification_to_receiver->document_id = $document->id;
               $notification_to_receiver->user_id = $document->contact->userByMobileNumber->id;
               $notification_to_receiver->save();
           }
           // when receiver send back
           elseif ($document->status == 1){
               if ($request->has('receiver_sign')) {
                   $filename = base64_to_image_sign($request['receiver_sign']);
                   $document->receiver_sign = $filename;
               }
               else {
                   $document->receiver_sign = $document->contact->userByMobileNumber->sign_image;
               }
               $document->status = $document->auto_sign == 1 ? 3 : 2;
               $document->save();

               if ($document->status == 2) {
                   $notification_to_sender = new Notification();
                   $notification_to_sender->comment = "You have signed the document(#" . $document->id . ")";
                   $notification_to_sender->type = 'document';
                   $notification_to_sender->document_id = $document->id;
                   $notification_to_sender->user_id = $document->user_id;
                   $notification_to_sender->save();
               }

               if ($document->status == 3) {
                   $notification_to_receiver = new Notification();
                   $notification_to_receiver->comment = "Document(#" . $document->id . ") has been completed";
                   $notification_to_receiver->type = 'document';
                   $notification_to_receiver->document_id = $document->id;
                   $notification_to_receiver->user_id = $document->contact->userByMobileNumber->id;
                   $notification_to_receiver->save();
               }

               // deduct credit point
               $template = TemplateManagement::where(['slug'=>'nda_doc', 'status'=>1])->first();
               if ($template){
                   $user_transaction = UserTransaction::where('user_id', $document->user_id)->first();
                   if ($user_transaction){
                       if ($user_transaction->plan_id != 3){
                           $user_transaction->credit_points = $user_transaction->credit_points - $template->credit_points;
                           $user_transaction->save();
                       }
                       $transaction = new Transaction();
                       $transaction->document_id = $document->id;
                       $transaction->user_id = $document->user_id;
                       $transaction->contact_id = $document->contact_id;
                       $transaction->credit_points = $template->credit_points;
                       $transaction->save();
                   }
               }
           }

           //for nda template document
            $temp_path = 'public/storage/uploads/pdf/';
            if ($document) {
                    $sender_detail = json_decode($document->sender_details);

                    $receiver_detail = json_decode($document->receiver_details);

                //$sender_sign = $document->sender_sign ?? $document->user->sign_image;
                $sender_sign = $document->sender_sign;
                //$receiver_sign = $document->receiver_sign ?? $document->contact->userByMobileNumber->sign_image;
                $receiver_sign = $document->receiver_sign;
                $user_data = [
                    'sender_first_name' => ucfirst($sender_detail->first_name),
                    'sender_last_name' => ucfirst($sender_detail->last_name),
                    'receiver_first_name' => ucfirst($receiver_detail->first_name),
                    'receiver_last_name' => ucfirst($receiver_detail->last_name),
                    'content' => $document->content,
                    'sender_date' => Carbon::parse($sender_detail->created_at),
                    'receiver_date' => Carbon::parse($receiver_detail->created_at),
                    'sender_sign_image' => '<img width="50" height="50" src="'.asset("public/storage/uploads/user-sign/".$sender_sign).'"/>',
                    'receiver_sign_image' => '<img width="50" height="50" src="'.asset("public/storage/uploads/user-sign/".$receiver_sign).'"/>',
                ];
                $email_template = TemplateManagement::where('slug', 'nda_doc')->first();

                $message = str_replace(array('{sender_first_name}','{sender_last_name}', '{receiver_first_name}','{receiver_last_name}', '{content}', '{sender_date}', '{receiver_date}', '{sender_sign_image}', '{receiver_sign_image}'), $user_data, $email_template->content);
                $mpdf = new Mpdf(['tempDir' => $temp_path]);
                $mpdf->WriteHTML($message);
                $pdf_name = 'NDA-'. $document->id . '.pdf';
                $mpdf->Output($temp_path . $pdf_name, 'F');
                $content_pdf = asset($temp_path . $pdf_name);
                $document->pdf = $pdf_name;
                $document->save();
            }
            $document['template_path'] = $content_pdf;
            $document['is_received'] = $document->user_id == auth('api')->id() ? 0 : 1;
            $document->sender_details = json_decode($document->sender_details);
            $document->receiver_details = json_decode($document->receiver_details);
            $message = [];
            if ($document->status==3){
                $message = "Document(#".$document->id.") has been completed.";
            }
            elseif ($document->status==2){
                $message = "Success! You have signed this document and it has been sent back to the Sender.";
            }
            else{
                $message = "Your sign has been placed.";
            }

           return response()->json([
                "status" => 1,
                //"message" => $document->status==3 ? "Document(#".$document->id.") has been completed." : "Your sign has been placed.",
               "message" => $message,
               'contact_image_path' => URL::to('/') . '/public/storage/uploads/contact-image/',
               'profile_image_path' => URL::to('/').'/public/storage/uploads/user-profile/',
               'sign_image_path' => URL::to('/').'/public/storage/uploads/user-sign/',
               "template_path" => $content_pdf,
               "data" => $document,
           ]);
        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }

    public function notarizeChange(Request $request){
        $validator = Validator::make($request->all(),[
            'document_id' => 'required|exists:documents,id',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        try {
            $document = Document::with('stateUs:id,name', 'user:id,first_name,last_name,profile_image,sign_image', 'contact.userByMobileNumber')
                ->where('id', $request['document_id'])->first();
            //$user = auth('api')->user();

            if ($document->notarize == 0) {
                $user = auth('api')->user();

//                $global = GlobalSettingManagement::first();
//                //for user charge by stripe
//                $stripe = new StripeClient(
//                    env('STRIPE_SECRET')
//                );
//                $default_source = $stripe->customers->retrieve(
//                    $user->stripe_customer_id
//                );
//                //dd($default_source);
//                if ($default_source) {
//                    $charge = $stripe->charges->create([
//                        'amount' => $global->notarize_amount * 100,
//                        'currency' => 'usd',
//                        'source' => $default_source->default_source,
//                        'description' => 'My First Test Charge (created for API docs)',
//                    ]);
//                }
                    $document->notarize = 1;
                    $document->save();
                    $mail_array = [
                        'first_name' => ucfirst($user['first_name']),
                        'last_name' => ucfirst($user['last_name']),
                        'document_id' => $request['document_id'],
                    ];

                    $email_template = EmailTemplateManagement::where('slug', 'notary_email')->first();
                    $message = str_replace(array('{first_name}', '{last_name}', '{document_id}'), $mail_array, $email_template->content);
                    //dd($message);
                    $to_mail = "ankiakumari.ca@gmail.com";
                    $subject = $email_template->subject;
                    $from_mail = "chris.predovic@ethereal.email";

                    $data['msg'] = $message;

                    Mail::send('admin.emails.notary-change', $data, function ($message) use ($to_mail, $subject, $from_mail) {
                            $message->to($to_mail);
                            $message->subject($subject);
                            $message->from($from_mail);
                           //$message->from("chris.predovic@ethereal.email");
                    });

                    $document->sender_details = json_decode($document->sender_details);
                    $document->receiver_details = json_decode($document->receiver_details);

                    return response()->json([
                        "status" => 1,
                        "message" => 'Your notary request has been sent to support@getgonda.com.',
                        'contact_image_path' => URL::to('/') . '/public/storage/uploads/contact-image/',
                        'profile_image_path' => URL::to('/') . '/public/storage/uploads/user-profile/',
                        'sign_image_path' => URL::to('/') . '/public/storage/uploads/user-sign/',
                        "data" => $document
                    ]);
                }

            return response()->json([
                "status" => 0,
                "message" => 'Your notary request has not been sent to support@getgonda.com.',
                "data" => []
            ]);
        }
            catch
                (\Exception $exception){
                    return error_response($exception);
                }

        }

    public function draftList(Request $request)
    {
        $drafts = Document::with('contact')->where([
            'user_id' => auth('api')->id(),
            'type' => 2,
        ])->get();
        $document_by_batch = $drafts->groupBy('batch');
        $response = [];
        $contact_data= [];
        if ($document_by_batch->isNotEmpty()) {
            foreach ($document_by_batch as $batch => $draft_data){
                $batch_contact_data = [];
                foreach ($draft_data as $data){
                    $batch_contact_data[] = [
                        'document_id' => $data->id,
                        'contact_id' => $data->contact->id,
                        'contact_first_name' => $data->contact->contact_first_name,
                        'contact_last_name' => $data->contact->contact_last_name,
                        'contact_mobile_number' => $data->contact->contact_mobile_number,
                        'contact_country_code' => $data->contact->contact_country_code,
                        'contact_image' => $data->contact->contact_image,
                    ];
                }
                //$data = $data->toArray();
                $response[] = [
                    'contacts' => $batch_contact_data,
                    'ndaContent' => $draft_data[0]['content'],
                    'autoSign' => $draft_data[0]['auto_sign'],
                    'template' => $draft_data[0]['template'],
                    'state_id' => $draft_data[0]['state_id'],
                ];
            }
            return response()->json([
                "status" => 1,
                "message" => 'Draft list data',
                "contact_image_path" => URL::to('/') . '/public/storage/uploads/contact-image/',
                "data" => $response
            ]);
        }
        return response()->json([
            "status" => 1,
            "message" => 'No Records',
            "data" => []
        ]);
    }

    public function templateList(Request $request){
        $template = TemplateManagement::get();
        $response = [];
        $temp_path = 'public/storage/uploads/pdf/';
        if ($template->isNotEmpty()){
            foreach ($template as $key => $item) {
                $response [] = [
                    'id' => $item->id,
                    'credits' => $item->credit_points,
                ];
                $mpdf = new Mpdf(['tempDir' => $temp_path]);
                $mpdf->WriteHTML($item->content);
                $pdf_name = $item->title;
                //$pdf_name = 'NDA-'.$item->id.'.pdf';
                $content_pdf = $mpdf->Output($temp_path.$pdf_name,'F');
                $response[$key]['content_pdf'] = asset($temp_path.$pdf_name);
            }
        }
        return response()->json([
            'status' => 1,
            'message' => 'Template List',
            'data' => $response
        ]);
    }

    public function sendNdaOnEmail(Request $request){
        $validator = Validator::make($request->all(),[
            'document_id' => 'required|exists:documents,id',
            'email' => 'required|email|max:255',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        try{
            $document = Document::where('id', $request['document_id'])->first();
            $email_address = $request['email'];
            $pdf_file = URL::to('/').'/public/storage/uploads/pdf/'.$document->pdf;
            $subject = "GoNDA";
            $data= [
                'user_name' => "Name"
            ];
            if ($document){
                Mail::send('admin.emails.template',$data, function ($message) use ($email_address, $subject, $pdf_file) {
                    $message->to($email_address)
                        ->subject($subject)
                        ->from(env('MAIL_FROM_ADDRESS'))
                        ->attach($pdf_file);
                });
                return response()->json([
                    'status' => 1,
                    'message' => 'Email has been sent successfully.',
                ]);
            }
            return response()->json([
                'status' => 1,
                'message' => 'Something went wrong.',
            ]);
        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }

    public function reminderSentAt(Request $request){
        $validator = Validator::make($request->all(),[
            'document_id' => 'required|exists:documents,id',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        try{
            $document = Document::with('stateUs:id,name','user:id,first_name,last_name,profile_image,sign_image','contact.userByMobileNumber')->where(['id' => $request['document_id'], 'user_id' => auth('api')->id()])->first();
            //dd($document->contact->userByMobileNumber->id);
            if (!empty($document)){
                $document->reminder_sent_at = Carbon::now();
                $document->save();

                $sender_detail = json_decode($document->sender_details);

                $receiver_detail = json_decode($document->receiver_details);


                if (!empty($receiver_detail)){
                    $user_details = [
                        'first_name' => ucfirst($receiver_detail->first_name) ?? '',
                        'last_name' => ucfirst($receiver_detail->last_name) ?? '',
                        'email' => $receiver_detail->email,
                        'country_code' =>$receiver_detail->country_code ?? '',
                        'mobile_number' =>$receiver_detail->mobile_number ?? '',
                    ];

                    //send_email($user_details, 'reminder_mail', 'reminder');

                    $document_id = $document->id ?? null;
                    twilio_sms($user_details['country_code'], $user_details['mobile_number'],null, "You have received reminder for document(#".$document_id.") sign.");
                }


                $notification = new Notification();
                $notification->comment = "You have received reminder for document(#".$document->id.") sign.";
                $notification->type = 'document';
                $notification->document_id = $document->id;
                $notification->user_id = $document->contact->userByMobileNumber->id ?? null;
                $notification->save();
                $document->sender_details = $sender_detail;
                $document->receiver_details = $receiver_detail;
                return response()->json([
                    'status' => 1,
                    'message' => 'Reminder has been sent.',
                    'contact_image_path' => URL::to('/') . '/public/storage/uploads/contact-image/',
                    'profile_image_path' => URL::to('/').'/public/storage/uploads/user-profile/',
                    'sign_image_path' => URL::to('/').'/public/storage/uploads/user-sign/',
                    'data' => $document
                ]);
            }
            return response()->json([
                'status' => 1,
                'message' => 'Document data',
                'data' => $document
            ]);
        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }

    public function subscriptionList(Request $request){
        try{
            $plan = HomeSection6::where('status', 1)->get();
            $transaction = Transaction::with('contact.userByMobileNumber')
                                        ->where('user_id', auth('api')->id())
                                        ->get();
            $receiver_data = [];
            if ($transaction->isNotEmpty()){
                foreach ($transaction as $transaction_data){
                    $receiver_data[] = [
                    'document_id' => $transaction_data->document_id,
                    'first_name' => $transaction_data->contact->userByMobileNumber->first_name,
                    'last_name' => $transaction_data->contact->userByMobileNumber->last_name,
                    'profile_image' =>$transaction_data->contact->userByMobileNumber->profile_image,
                    'credit_points' => $transaction_data->credit_points,
                    'created_at' => $transaction_data->contact->userByMobileNumber->created_at,
                    ];
                }
            }
            if ($plan->isNotEmpty()){
                return response()->json([
                    'status' => 1,
                    'message' => 'Subscription List',
                    'profile_image_path' => URL::to('/').'/public/storage/uploads/user-profile/',
                    'data' => $plan,
                    'card_list' => StripePaymentController::cardList(),
                    'current_plan' => HomeSection6::userTransactions(),
                    'transaction' => $receiver_data,
                    'can_cancelled_subscription' => HomeSection6::canCancelledSubscription(),
                ]);
            }
            return response()->json([
                'status' => 1,
                'message' => 'No Records',
                'data' => []
            ]);
        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }

    public function documentDetail(Request $request){
        $validator = Validator::make($request->all(),[
            'document_id' => 'required|exists:documents,id',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        try{
            $document = Document::with('contact.userByMobileNumber','stateUs:id,name','user:id,first_name,last_name,profile_image,sign_image')
                                ->where('id', $request['document_id'])->first();
            if (!empty($document)){
                $document->is_received = $document->user_id == auth('api')->id() ? 0 : 1;
                $document->sender_details = json_decode($document->sender_details);
                $document->receiver_details = json_decode($document->receiver_details);
                return response()->json([
                    'status' => 1,
                    'message' => 'Document Details',
                    'contact_image_path' => URL::to('/') . '/public/storage/uploads/contact-image/',
                    'profile_image_path' => URL::to('/').'/public/storage/uploads/user-profile/',
                    'sign_image_path' => URL::to('/').'/public/storage/uploads/user-sign/',
                    'template_path' => URL::to('/').'/public/storage/uploads/pdf/',
                    'data' => $document
                ]);
            }
            return response()->json([
                'status' => 1,
                'message' => 'No Records.',
                'data' => []
            ]);
        }
        catch (\Exception $exception){
            return error_response($exception);
        }
    }


    public function Docupdate(Request $request)
    {
 $validator = Validator::make($request->all(),[
            'contacts' => 'required|array',
            'contacts.*.contact_id' => 'required|exists:contacts,id',
            'contacts.*.document_id' => 'sometimes|nullable|exists:documents,id',
            'content' => 'required|string',
            'state_id' => 'required',
            'template' => 'required',
            'auto_sign' => 'required|in:0,1',
            'type' => 'required|in:1,2',
        ],[
            'contact_id.*.exists' => 'The entered contact id does not exists.',
            'contact_id.*.unique' => 'The contact id has already been taken.',
        ]);
        if ($validator->fails()){
            $error = $validator->errors()->first();
            return response()->json([
                "status" => 0,
                "message" => $error,
            ]);
        }
        $document_data = [];
        $user_data = [];

             foreach ($request['to_delete_docs'] as $deletecontact){
               Document::where('id',$deletecontact['document_id'])->where('contact_id',$deletecontact['contact_id'])->delete();
             }

           $batch_id = Document::where('id',$request['document_id'])->first();

        try {
            DB::beginTransaction();
            $user = auth('api')->user();
            $global_setting = GlobalSettingManagement::first();
            if (!empty($request['contacts'])){
                $last_draft = Document::where('type',2)->latest()->first('batch');
                $batch = !empty($last_draft) ? $last_draft->batch + 1 : 1;
                foreach ($request['contacts'] as $contact){
                 $updatedoc = Document::where('id',$contact['document_id'])->where('contact_id',$contact['contact_id'])->first();
                    if(!empty($updatedoc)) {
                        $document = Document::find($contact['document_id']);
                        $document->content    = $request['content'];
                        $document->state_id   = $request['state_id'];
                        $document->template   = $request['template'];
                        $document->auto_sign  = $request['auto_sign'];
                        $document->sender_sign= $request['auto_sign'] == 1 ? $user->sign_image : null;
                        $document->save();
                        $document_data[] = $document;
                    }
                    else {
                        $document = new Document();
                        $document->user_id    = auth('api')->id();
                        $document->contact_id = $contact['contact_id'];
                        $document->content    = $request['content'];
                        $document->state_id   = $request['state_id'];
                        $document->template   = $request['template'];
                        $document->auto_sign  = $request['auto_sign'];
                        $document->sender_sign= $request['auto_sign'] == 1 ? $user->sign_image : null;
                        $document->type       = $request['type'];
                        $document->status     = $request['type'] == 1 ? 1 : 0;
                        $document->batch      = $batch_id->batch;
                        $document->save();

                        // update sender and receiver details
                        $document->sender_details = json_encode($document->user);
                        $document->receiver_details = json_encode($document->contact->userByMobileNumber);
                        $document->save();

                        $notification_to_sender = new Notification();
                        $notification_to_sender->comment = "You have sent document(#".$document->id.") to ".ucfirst($document->contact->contact_first_name)." ".ucfirst($document->contact->contact_last_name);
                        $notification_to_sender->type = 'document';
                        $notification_to_sender->document_id = $document->id;
                        $notification_to_sender->user_id = $document->user_id;
                        $notification_to_sender->save();

                        $notification_to_receiver = new Notification();
                        $notification_to_receiver->comment = "You have received document(#".$document->id.") to sign from ".ucfirst($document->user->first_name)." ".ucfirst($document->user->last_name);
                        $notification_to_receiver->type = 'document';
                        $notification_to_receiver->document_id = $document->id;
                        $notification_to_receiver->user_id = $document->contact->userByMobileNumber->id ?? null;
                        $notification_to_receiver->save();

                        $document['global_content'] = $global_setting->content;
                        $document_data[] = $document;
                    }
                }
                if ($document_data){
                    foreach ($document_data as $contact_data){
                        $contact = Contact::where('id', $contact_data->contact_id)->first();
                        if ($contact){
                            $user = User::where('mobile_number', $contact->contact_mobile_number)->first();
                            if ($user){
                                $user_data = $user->sign_image;
                            }
                        }
                    }
                }
                DB::commit();
                return response()->json([
                    'status' => 1,
                    'message' => "Your document has been updated",
                    'sign_image_path' => URL::to('/').'/public/storage/uploads/user-sign/',
                    'data' => $document_data,
                    'sign_image' => $user_data,
                ]);
            }

        }
        catch (\Exception $exception){
            return error_response($exception);
        }

    }

    public function cancel_document(Request $request)
    {
      $validator = Validator::make($request->all(),[
            'document_id' => 'required',
        ]);

      if ($validator->fails()){
          $error = $validator->errors()->first();
          return response()->json([
              "status" => 0,
              "message" => $error,
          ]);
      }

      Document::where('id',$request['document_id'])->update(['is_cancel'=>1]);
      $data = Document::where('id',$request['document_id'])->first();

      return response()->json([
          'status' => 1,
          'message' => "Your document has been cancelled",
          'data' => $data,
      ]);

    }

      public function docDelete(Request $request)
    {
      $validator = Validator::make($request->all(),[
            'document_id' => 'required',
        ]);

      if ($validator->fails()){
          $error = $validator->errors()->first();
          return response()->json([
              "status" => 0,
              "message" => $error,
          ]);
      }

      Document::where('id',$request['document_id'])->delete();
      return response()->json([
          'status' => 1,
          'message' => "Your draft has been Deleted",
      ]);

    }

}
