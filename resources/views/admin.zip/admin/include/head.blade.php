<title>goNDA</title>
@toastr_css
<!--[if lt IE 10]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<!-- Favicon icon -->
<link rel="icon" href="{{asset('public/gonda-logo/gonda_favicon.ico')}}" type="image/x-icon">
<!-- Google font-->
<link href="https://fonts.googleapis.com/css?family=Roboto:400,500" rel="stylesheet">
<!-- waves.css -->
<link rel="stylesheet" href="{{asset('public/files/assets/pages/waves/css/waves.min.css')}}" type="text/css" media="all">
<!-- Required Fremwork -->
<link rel="stylesheet" type="text/css" href="{{asset('public/files/bower_components/bootstrap/css/bootstrap.min.css')}}">
<link href="{{asset('public/files/assets/pages/jquery.filer/css/jquery.filer.css')}}" type="text/css" rel="stylesheet" />
<link href="{{asset('public/files/assets/pages/jquery.filer/css/themes/jquery.filer-dragdropbox-theme.css')}}" type="text/css" rel="stylesheet" />
<!-- themify icon -->
<link rel="stylesheet" type="text/css" href="{{asset('public/files/assets/icon/themify-icons/themify-icons.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('public/files/assets/icon/icofont/css/icofont.css')}}">
<!-- scrollbar.css -->
<link rel="stylesheet" type="text/css" href="{{asset('public/files/assets/css/jquery.mCustomScrollbar.css')}}">
<!-- am chart export.css -->
<link rel="stylesheet" href="{{asset('public/www.amcharts.com/lib/3/plugins/export/export.css')}}" type="text/css" media="all" />
<!-- radial chart.css -->
<link rel="stylesheet" href="{{asset('public/files/assets/pages/chart/radial/css/radial.css')}}" type="text/css" media="all">
<!-- Style.css -->
<link rel="stylesheet" type="text/css" href="{{asset('public/files/bower_components/switchery/css/switchery.min.css')}}">
<!-- Tags css -->
<link rel="stylesheet" type="text/css" href="{{asset('public/files/bower_components/bootstrap-tagsinput/css/bootstrap-tagsinput.css')}}" />

{{--<link rel="stylesheet" type="text/css" href="{{assert('public/files/bower_components/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}">--}}
{{--<link rel="stylesheet" type="text/css" href="{{asset('public/files/assets/pages/data-table/css/buttons.dataTables.min.css')}}">--}}
{{--<link rel="stylesheet" type="text/css" href="{{asset('public/files/bower_components/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}">--}}

<link rel="stylesheet" href="{{asset('public/files/bower_components/select2/css/select2.min.css')}}" />

<link rel="stylesheet" type="text/css" href="{{asset('public/files/assets/css/style.css')}}">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<style>
    .error
    {
        color: #ff0000 !important;
    }



</style>
