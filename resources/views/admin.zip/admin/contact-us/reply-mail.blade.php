<html lang="en-US">
<head>
    <meta charset="text/html">
</head>
<body>
{!! (isset($msg)) ? $msg : '' !!}
</body>
</html>
