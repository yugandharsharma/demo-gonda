<html lang="en-US">
<head>
    <meta charset="text/html">
</head>
<body>
<p>Hello {{$data['first_name']." ".$data['last_name']}},</p>
<p>{{$data['sender_first_name']." ".$data['sender_last_name']}} wants to notarized this document id {{$data['document_id']}} </p>
<p>Thanks</p>
</body>
</html>
